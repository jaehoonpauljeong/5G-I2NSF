#pragma once

#ifndef __cplusplus
#error Do not include the hpp header in a c project!
#endif //__cplusplus

extern "C"
{
#include "milenage.h"
}
